from django.apps import AppConfig


class NasaAPIConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'nasa_api'
